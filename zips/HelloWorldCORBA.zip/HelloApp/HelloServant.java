package HelloApp;

public class HelloServant extends HelloPOA{

  //Este simplemente va a ejecutar la funcion del Hello World
  public String sayHello(){
    return "Hola desde el Java Server!";
  }
}
